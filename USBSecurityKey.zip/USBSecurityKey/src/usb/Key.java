
package usb;


/**
 * 
 * @author paulmizzi
 *
 * @version 1.0 2026-11-13 Initial implementation
 *
 *
 * @since 1.0
 */
public class Key
    {
    private String oTP;
    private String encryptKey;
    }
   // end class Key